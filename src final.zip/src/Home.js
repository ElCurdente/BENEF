import React from 'react';
import Thread from "./Thread";

function Home() {
  return (
    <Thread/> /* Affiche le component Thread */
  )
}

export default Home
