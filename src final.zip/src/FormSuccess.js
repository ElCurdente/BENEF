import React from 'react'
import Accueil from './Accueil'

const FormSuccess = () => {
    return (
        <Accueil />
    )
}

export default FormSuccess
